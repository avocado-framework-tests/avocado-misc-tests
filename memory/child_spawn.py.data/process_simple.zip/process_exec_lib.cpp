#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include <linux/limits.h>
#include <sys/times.h>
#include <signal.h>
#include <pthread.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <pthread.h>
#include <spawn.h>
#include <sys/wait.h>
#include <string.h>

#include <sys/syscall.h>
#include <errno.h>
#include <malloc.h>
#include <sys/mman.h>

extern "C"
{
  __attribute__ ((visibility("default"))) void* malloc(size_t size)
  {
       return mmap(0, 268435456, 3, 34, -1, 0);
  }

  __attribute__ ((visibility("default"))) void* realloc(void* ptr, size_t size)
  {
       return mmap(0, 268435456, 3, 34, -1, 0);
  }

  __attribute__ ((visibility("default"))) void* mmap(void *addr, size_t length, int prot, int flags, int fd, off_t offset)
  {
	if(0 == addr && fd == -1)
	    addr = (void*) 0xffffffffffff0000;

	//fprintf(stderr, "%d %p %lu %i %i %i %li\n", SYS_mmap, addr, length, prot, flags, fd, offset);
 	void* rc = (void*)syscall(SYS_mmap, addr, length, prot, flags, fd, offset);
        //fprintf(stderr, "%p\n", rc);
        return rc;
  }

 __attribute__ ((visibility("default"))) void* mmap64(void *addr, size_t length, int prot, int flags, int fd, off_t offset)
  {
        if(0 == addr && fd == -1)
            addr = (void*) 0xffffffffffff0000;

        //fprintf(stderr, "%d %p %lu %i %i %i %li\n", SYS_mmap, addr, length, prot, flags, fd, offset);
        void* rc = (void*)syscall(SYS_mmap, addr, length, prot, flags, fd, offset);
        //fprintf(stderr, "%p\n", rc);
        return rc;
  }
}

