#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include <linux/limits.h>
#include <sys/times.h>
#include <signal.h>
#include <pthread.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <pthread.h>
#include <spawn.h>
#include <sys/wait.h>
#include <string.h>

#include <sys/syscall.h>
#include <errno.h>
#include <malloc.h>
#include <sys/mman.h>

static int mapPipe2StdStream(posix_spawn_file_actions_t* pFileActions, int stdFD, int pipeIdx, int commPipe[2])
{
  ::posix_spawn_file_actions_addclose(pFileActions, commPipe[pipeIdx]);
  ::posix_spawn_file_actions_addclose(pFileActions, stdFD);
  ::posix_spawn_file_actions_adddup2(pFileActions, commPipe[1- pipeIdx], stdFD);
  return 0;
}

int main(int argc, char** argv)
{
char* ptr = (char*)malloc(2000000000);
ptr[0] ='x';

char* ptr1 = (char*)mmap((void*)0, 268435456, 3, 34, -1, 0);
ptr1[0] ='x';
  fprintf(stderr, "%p %p\n", ptr1, ptr);

  char* myargv[3];
  myargv[0] = strdup("/bin/touch");
  myargv[1] = strdup("/tmp/my_touuuch.txt");
  myargv[2] = NULL;

  int inpPipe[] = {-1, -1};
  int outPipe[] = {-1, -1};
  int errPipe[] = {-1, -1};

  ::pipe(inpPipe);
  ::pipe(outPipe);
  ::pipe(errPipe);

  pid_t childPid;
  posix_spawnattr_t childAttr;
  posix_spawn_file_actions_t fileActions;

  ::posix_spawnattr_init(&childAttr);
  ::posix_spawn_file_actions_init(&fileActions);

  sigset_t emptySignalMask;
  ::sigemptyset(&emptySignalMask);
  ::posix_spawnattr_setsigdefault(&childAttr, &emptySignalMask);

  //mapPipe2StdStream(&fileActions, STDIN_FILENO, 1, inpPipe, cmdAux);
  //mapPipe2StdStream(&fileActions, STDOUT_FILENO, 0, outPipe, cmdAux);
  //mapPipe2StdStream(&fileActions, STDERR_FILENO, 0, errPipe, cmdAux);

  ::posix_spawnp(&childPid, *myargv, &fileActions, &childAttr, myargv, environ);
  
  ::close(inpPipe[0]);
  ::close(outPipe[1]);
  ::close(errPipe[1]);

  ::posix_spawn_file_actions_destroy(&fileActions);
  ::posix_spawnattr_destroy(&childAttr);

  int exitCode = 0;
  ::waitpid(childPid, &exitCode, 0);

printf("%c\n",ptr[0]);
printf("%c\n",ptr1[0]);

  return 0;
}
