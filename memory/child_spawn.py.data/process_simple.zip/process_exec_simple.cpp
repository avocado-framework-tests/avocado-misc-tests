#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include <linux/limits.h>
#include <sys/times.h>
#include <signal.h>
#include <pthread.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <pthread.h>
#include <spawn.h>
#include <sys/wait.h>
#include <string.h>

#include <sys/syscall.h>
#include <errno.h>
#include <malloc.h>
#include <sys/mman.h>

void* my_mmap(void *addr, size_t length, int prot, int flags, int fd, off_t offset)
{
#ifdef USE_HIGH_ADDR
  if(0 == addr && fd == -1)
     addr = (void*) 0xffffffffffff0000;
#endif
  return (void*)syscall(SYS_mmap, addr, length, prot, flags, fd, offset);
}

void* my_malloc()
{
  return my_mmap(0, 268435456, 3, 34, -1, 0);
}

int main(int argc, char** argv)
{
  char** myargv = (char**)my_malloc();
  fprintf(stderr, "%p\n", (void*)myargv);

  char* ptr = (char*)(myargv+3);
  myargv[0] = ptr;
  strcpy(ptr, "/bin/touch");
  ptr += (strlen(ptr) + 1);
  myargv[1] = ptr;
  strcpy(ptr, "/tmp/my_touch.txt");
  myargv[2] = NULL;

  pid_t childPid;
  posix_spawnattr_t childAttr;
  posix_spawn_file_actions_t fileActions;

  ::posix_spawnattr_init(&childAttr);
  ::posix_spawn_file_actions_init(&fileActions);

  sigset_t emptySignalMask;
  ::sigemptyset(&emptySignalMask);
  ::posix_spawnattr_setsigdefault(&childAttr, &emptySignalMask);

  ::posix_spawnp(&childPid, *myargv, &fileActions, &childAttr, myargv, environ);
  
  ::posix_spawn_file_actions_destroy(&fileActions);
  ::posix_spawnattr_destroy(&childAttr);

  int exitCode = 0;
  ::waitpid(childPid, &exitCode, 0);

  return 0;
}

