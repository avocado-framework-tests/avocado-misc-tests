/*Author:Ravi Bangoria <ravi.bangoria@linux.ibm.com>*/
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>

extern long swap_long(long *, long *, long *, long *);
long arg1 = 10;
long arg2 = 20;

static ssize_t wptest_read(struct file *f, char *buf, size_t count, loff_t *ppos)
{
	char b[100];
	int len;
	long tmp1, tmp2;

	if (*ppos != 0)
		return 0;

	swap_long(&arg1, &arg2, &tmp1, &tmp2);

	sprintf(b, "%ld %ld\n", arg1, arg2);
	len = strlen(b);

	if (copy_to_user(buf, b, len))
		return -EINVAL;

	*ppos = len;
	return len;
}

static const struct file_operations wptest_fops = {
	.owner	= THIS_MODULE,
	.read	= wptest_read,
};

static struct miscdevice wptest_dev = {
	MISC_DYNAMIC_MINOR,
	"wptest",
	&wptest_fops
};

static int __init wptest_init(void)
{
	return misc_register(&wptest_dev);
}
module_init(wptest_init);

static void __exit wptest_exit(void)
{
	misc_deregister(&wptest_dev);
}
module_exit(wptest_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Ravi Bangoria <ravi.bangoria@linux.ibm.com>");
MODULE_DESCRIPTION("Watchpoint test module.");
